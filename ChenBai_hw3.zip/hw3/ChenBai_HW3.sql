
/*create view TotalPoints*/
DROP VIEW IF EXISTS TotalPoints;
CREATE VIEW TotalPoints AS
SELECT * FROM Rawscores WHERE SSN=0001;

/*create view Weights*/
DROP VIEW IF EXISTS Weights;
CREATE VIEW Weights AS
SELECT * FROM Rawscores WHERE SSN=0002;


/*(a) Create procedure ShowRawScores*/
/* delimiter // */
DROP PROCEDURE IF EXISTS ShowRawScores;
CREATE PROCEDURE ShowRawScores(IN s VARCHAR(4))
BEGIN
IF EXISTS(SELECT SSN FROM Rawscores WHERE SSN=s) THEN
SELECT SSN, LName, FName, Section, HW1, HW2a, HW2b, Midterm, HW3, FExam 
FROM Rawscores 
WHERE SSN = s;
ELSE
SELECT 'Sorry, this ssn is invalid' AS 'Error Message';
END IF;
END; 

/*Create View WtdPts*/
DROP VIEW IF EXISTS WtdPts;
CREATE VIEW WtdPts AS 
SELECT (1/t.HW1)*w.HW1 as HW1, (1/t.HW2a)*w.HW2a as HW2a, (1/t.HW2b)*w.HW2b as HW2b, (1/t.Midterm)*w.Midterm as Midterm, (1/t.HW3)*w.HW3 as HW3, (1/t.FExam)*w.FExam as FExam
FROM TotalPoints as t, Weights as w;

/*(b) Create procedure ShowPercentage*/
DROP PROCEDURE IF EXISTS ShowPercentages;
CREATE PROCEDURE ShowPercentages(IN s VARCHAR(4))
BEGIN
IF EXISTS(SELECT SSN FROM Rawscores WHERE SSN=s) THEN
SELECT r.SSN, CONCAT(r.FName,' ', r.LName) as Name, r.Section, (r.HW1/t.HW1)*100 as HW1, (r.HW2a/t.HW2a)*100 as HW2a,(r.HW2b/t.HW2b)*100 as HW2b,(r.Midterm/t.Midterm)*100 as Midterm,(r.HW3/t.HW3)*100 as HW3,(r.FExam/t.FExam)*100 as FExam,((r.HW1*w.HW1) + (r.HW2a*w.HW2a) + (r.HW2b*w.HW2b) + (r.Midterm*w.Midterm) + (r.HW3*w.HW3) + (r.FExam*w.FExam)) as CumAvg
FROM Rawscores as r, WtdPts as w, TotalPoints as t
WHERE r.SSN = s;
ELSE
SELECT 'Sorry, this ssn is invalid' AS 'Error Message';
END IF;
END; 


/*(c) Create procedure AllRawScores*/
DROP PROCEDURE IF EXISTS AllRawScores;
CREATE PROCEDURE AllRawScores(IN pw VARCHAR(15))
BEGIN
IF EXISTS(SELECT CurPasswords FROM Passwords WHERE CurPasswords=pw) THEN
SELECT SSN, LName, FName, Section, HW1, HW2a, HW2b, Midterm, HW3, FExam 
FROM Rawscores 
WHERE SSN != 0001 AND SSN != 0002
ORDER BY Section, LName, FName;
ELSE
SELECT 'Sorry, the password is invalid' AS 'Error Message';
END IF;
END; 



/*(d) Create procedure AllPercentages*/
DROP PROCEDURE IF EXISTS AllPercentages;
CREATE PROCEDURE AllPercentages(IN pw VARCHAR(15))
BEGIN
IF EXISTS(SELECT CurPasswords FROM Passwords WHERE CurPasswords=pw) THEN
SELECT r.SSN, CONCAT(r.FName,' ', r.LName) as Name, r.Section, (r.HW1/t.HW1)*100 as HW1, (r.HW2a/t.HW2a)*100 as HW2a,(r.HW2b/t.HW2b)*100 as HW2b,(r.Midterm/t.Midterm)*100 as Midterm,(r.HW3/t.HW3)*100 as HW3,(r.FExam/t.FExam)*100 as FExam, ((r.HW1*w.HW1) + (r.HW2a*w.HW2a) + (r.HW2b*w.HW2b) + (r.Midterm*w.Midterm) + (r.HW3*w.HW3) + (r.FExam*w.FExam)) as CumAvg
FROM Rawscores as r, WtdPts as w, TotalPoints as t
WHERE r.SSN != 0001 AND r.SSN != 0002
ORDER BY Section, CumAvg;
ELSE
SELECT 'Sorry, the password is invalid' AS 'Error Message';
END IF;
END; 


/*(e) Stats*/
DROP PROCEDURE IF EXISTS Stats;
CREATE PROCEDURE Stats(IN pw VARCHAR(15))
BEGIN
IF EXISTS(SELECT CurPasswords FROM Passwords WHERE CurPasswords=pw) THEN
SELECT 'Mean' as Statistic, '315/415/615' as Section,  AVG(HW1) as HW1, AVG(HW2a) as HW2a, AVG(HW2b) as HW2b, AVG(Midterm) as Midterm, AVG(HW3) as HW3, AVG(FExam) as FExam, AVG(CumAvg) as CumAvg
FROM
(SELECT (r.HW1/t.HW1)*100 as HW1, (r.HW2a/t.HW2a)*100 as HW2a,(r.HW2b/t.HW2b)*100 as HW2b,(r.Midterm/t.Midterm)*100 as Midterm,(r.HW3/t.HW3)*100 as HW3,(r.FExam/t.FExam)*100 as FExam, ((r.HW1*w.HW1) + (r.HW2a*w.HW2a) + (r.HW2b*w.HW2b) + (r.Midterm*w.Midterm) + (r.HW3*w.HW3) + (r.FExam*w.FExam)) as CumAvg
FROM Rawscores as r, WtdPts as w, TotalPoints as t
WHERE r.SSN != 0001 AND r.SSN != 0002) R1;

SELECT 'Minimum' as Statistic, '315/415/615' as Section,  MIN(HW1) as HW1, MIN(HW2a) as HW2a, MIN(HW2b) as HW2b, MIN(Midterm) as Midterm, MIN(HW3) as HW3, MIN(FExam) as FExam, MIN(CumAvg) as CumAvg
FROM
(SELECT (r.HW1/t.HW1)*100 as HW1, (r.HW2a/t.HW2a)*100 as HW2a,(r.HW2b/t.HW2b)*100 as HW2b,(r.Midterm/t.Midterm)*100 as Midterm,(r.HW3/t.HW3)*100 as HW3,(r.FExam/t.FExam)*100 as FExam, ((r.HW1*w.HW1) + (r.HW2a*w.HW2a) + (r.HW2b*w.HW2b) + (r.Midterm*w.Midterm) + (r.HW3*w.HW3) + (r.FExam*w.FExam)) as CumAvg
FROM Rawscores as r, WtdPts as w, TotalPoints as t
WHERE r.SSN != 0001 AND r.SSN != 0002) R1;

SELECT 'Maximum' as Statistic, '315/415/615' as Section,  MAX(HW1) as HW1, MAX(HW2a) as HW2a, MAX(HW2b) as HW2b, MAX(Midterm) as Midterm, MAX(HW3) as HW3, MAX(FExam) as FExam, MAX(CumAvg) as CumAvg
FROM
(SELECT (r.HW1/t.HW1)*100 as HW1, (r.HW2a/t.HW2a)*100 as HW2a,(r.HW2b/t.HW2b)*100 as HW2b,(r.Midterm/t.Midterm)*100 as Midterm,(r.HW3/t.HW3)*100 as HW3,(r.FExam/t.FExam)*100 as FExam, ((r.HW1*w.HW1) + (r.HW2a*w.HW2a) + (r.HW2b*w.HW2b) + (r.Midterm*w.Midterm) + (r.HW3*w.HW3) + (r.FExam*w.FExam)) as CumAvg
FROM Rawscores as r, WtdPts as w, TotalPoints as t
WHERE r.SSN != 0001 AND r.SSN != 0002) R1;

SELECT 'Std. Dev' as Statistic, '315/415/615' as Section,  STDDEV(HW1) as HW1, STDDEV(HW2a) as HW2a, STDDEV(HW2b) as HW2b, STDDEV(Midterm) as Midterm, STDDEV(HW3) as HW3, STDDEV(FExam) as FExam, STDDEV(CumAvg) as CumAvg
FROM
(SELECT (r.HW1/t.HW1)*100 as HW1, (r.HW2a/t.HW2a)*100 as HW2a,(r.HW2b/t.HW2b)*100 as HW2b,(r.Midterm/t.Midterm)*100 as Midterm,(r.HW3/t.HW3)*100 as HW3,(r.FExam/t.FExam)*100 as FExam, ((r.HW1*w.HW1) + (r.HW2a*w.HW2a) + (r.HW2b*w.HW2b) + (r.Midterm*w.Midterm) + (r.HW3*w.HW3) + (r.FExam*w.FExam)) as CumAvg
FROM Rawscores as r, WtdPts as w, TotalPoints as t
WHERE r.SSN != 0001 AND r.SSN != 0002) R1;

SELECT 'Mean' as Statistic, R1.Section,  AVG(HW1) as HW1, AVG(HW2a) as HW2a, AVG(HW2b) as HW2b, AVG(Midterm) as Midterm, AVG(HW3) as HW3, AVG(FExam) as FExam, AVG(CumAvg) as CumAvg
FROM
(SELECT r.Section, (r.HW1/t.HW1)*100 as HW1, (r.HW2a/t.HW2a)*100 as HW2a,(r.HW2b/t.HW2b)*100 as HW2b,(r.Midterm/t.Midterm)*100 as Midterm,(r.HW3/t.HW3)*100 as HW3,(r.FExam/t.FExam)*100 as FExam, ((r.HW1*w.HW1) + (r.HW2a*w.HW2a) + (r.HW2b*w.HW2b) + (r.Midterm*w.Midterm) + (r.HW3*w.HW3) + (r.FExam*w.FExam)) as CumAvg
FROM Rawscores as r, WtdPts as w, TotalPoints as t
WHERE r.SSN != 0001 AND r.SSN != 0002) R1
GROUP BY R1.Section ;

SELECT 'Minimum' as Statistic, R1.Section,  MIN(HW1) as HW1, MIN(HW2a) as HW2a, MIN(HW2b) as HW2b, MIN(Midterm) as Midterm, MIN(HW3) as HW3, MIN(FExam) as FExam, MIN(CumAvg) as CumAvg
FROM
(SELECT r.Section, (r.HW1/t.HW1)*100 as HW1, (r.HW2a/t.HW2a)*100 as HW2a,(r.HW2b/t.HW2b)*100 as HW2b,(r.Midterm/t.Midterm)*100 as Midterm,(r.HW3/t.HW3)*100 as HW3,(r.FExam/t.FExam)*100 as FExam, ((r.HW1*w.HW1) + (r.HW2a*w.HW2a) + (r.HW2b*w.HW2b) + (r.Midterm*w.Midterm) + (r.HW3*w.HW3) + (r.FExam*w.FExam)) as CumAvg
FROM Rawscores as r, WtdPts as w, TotalPoints as t
WHERE r.SSN != 0001 AND r.SSN != 0002) R1
GROUP BY R1.Section;

SELECT 'Maximum' as Statistic, R1.Section,  MAX(HW1) as HW1, MAX(HW2a) as HW2a, MAX(HW2b) as HW2b, MAX(Midterm) as Midterm, MAX(HW3) as HW3, MAX(FExam) as FExam, MAX(CumAvg) as CumAvg
FROM
(SELECT r.Section, (r.HW1/t.HW1)*100 as HW1, (r.HW2a/t.HW2a)*100 as HW2a,(r.HW2b/t.HW2b)*100 as HW2b,(r.Midterm/t.Midterm)*100 as Midterm,(r.HW3/t.HW3)*100 as HW3,(r.FExam/t.FExam)*100 as FExam, ((r.HW1*w.HW1) + (r.HW2a*w.HW2a) + (r.HW2b*w.HW2b) + (r.Midterm*w.Midterm) + (r.HW3*w.HW3) + (r.FExam*w.FExam)) as CumAvg
FROM Rawscores as r, WtdPts as w, TotalPoints as t
WHERE r.SSN != 0001 AND r.SSN != 0002) R1
GROUP BY R1.Section;

SELECT 'Std. Dev' as Statistic, R1.Section, STDDEV(HW1) as HW1, STDDEV(HW2a) as HW2a, STDDEV(HW2b) as HW2b, STDDEV(Midterm) as Midterm, STDDEV(HW3) as HW3, STDDEV(FExam) as FExam, STDDEV(CumAvg) as CumAvg
FROM
(SELECT r.Section, (r.HW1/t.HW1)*100 as HW1, (r.HW2a/t.HW2a)*100 as HW2a,(r.HW2b/t.HW2b)*100 as HW2b,(r.Midterm/t.Midterm)*100 as Midterm,(r.HW3/t.HW3)*100 as HW3,(r.FExam/t.FExam)*100 as FExam, ((r.HW1*w.HW1) + (r.HW2a*w.HW2a) + (r.HW2b*w.HW2b) + (r.Midterm*w.Midterm) + (r.HW3*w.HW3) + (r.FExam*w.FExam)) as CumAvg
FROM Rawscores as r, WtdPts as w, TotalPoints as t
WHERE r.SSN != 0001 AND r.SSN != 0002) R1
GROUP BY R1.Section;

ELSE
SELECT 'Sorry, the password is invalid' AS 'Error Message';
END IF;
END; 

/*(f) ChangeScores*/
DROP PROCEDURE IF EXISTS ChangeScores;
CREATE PROCEDURE ChangeScores(IN pw VARCHAR(15), IN s VARCHAR(4), IN a VARCHAR(10), IN g DECIMAL(5,2))
BEGIN
IF EXISTS(SELECT CurPasswords FROM Passwords WHERE CurPasswords=pw) 
AND EXISTS(SELECT SSN FROM Rawscores WHERE SSN=s)
THEN
SELECT SSN, LName, FName, Section, HW1, HW2a, HW2b, Midterm, HW3, FExam 
FROM Rawscores 
WHERE SSN = s ;
ELSE
SELECT 'Invalid Input' AS 'Error Message';
END IF;

IF EXISTS(SELECT CurPasswords FROM Passwords WHERE CurPasswords=pw) 
AND EXISTS(SELECT SSN FROM Rawscores WHERE SSN=s)
AND g is not null
AND a is not null
AND g>0 
THEN 
CASE a
  WHEN 'HW1' THEN UPDATE Rawscores SET HW1=g WHERE SSN=s; 
  WHEN 'HW2a' THEN UPDATE Rawscores SET HW2a=g WHERE SSN=s; 
  WHEN 'HW2b' THEN UPDATE Rawscores SET HW2b=g WHERE SSN=s; 
  WHEN 'Midterm' THEN UPDATE Rawscores SET Midterm=g WHERE SSN=s;
  WHEN 'HW3' THEN UPDATE Rawscores SET HW3=g WHERE SSN=s; 
  WHEN 'FExam' THEN UPDATE Rawscores SET FExam=g WHERE SSN=s; 
END CASE;

SELECT SSN, LName, FName, Section, HW1, HW2a, HW2b, Midterm, HW3, FExam 
FROM Rawscores
WHERE SSN=s;

ELSE
SELECT 'Invalid Input' AS 'Error Message';
END IF;
END; 











