<head>
  <title>ChangeScores</title>
</head>
<body>



 <?php
// PHP code just started

//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', true);

ini_set("display_errors", 0);

//error_reporting(E_ALL ^ E_NOTICE);

//error_reporting(E_ALL ^ E_WARNING);
// display errors

$db = mysqli_connect("dbase.cs.jhu.edu", "20fa_cbai6", "lCkL3uhlXF");
// ********* Remember to use your MySQL username and password here ********* //

if (!$db) {

  echo "Connection failed!";

} else {
  $password = $_POST['password'];
  $ssn = $_POST['SSN'];
  $asn = $_POST['asn'];



  $ng = $_POST['ng'];
  // This says that the $cr_cnt variable should be assigned a value obtained as an
  // input to the PHP code. In this case, the input is called 'cr_cnt'.

  mysqli_select_db($db,"20fa_cbai6_db");
  // ********* Remember to use the name of your database here ********* //

$x=1;
  if(mysqli_multi_query($db, "CALL ChangeScores('$password','$ssn','$asn','$ng')")){
      do
      { if($x==1){echo "Before Change";}
        if($x==2){echo "After Change";}
        $x++;
        echo "<table border=1>\n";
        echo "<tr><td>SSN</td><td>LName</td><td>FName</td><td>Section</td><td>HW1</td><td>HW2a</td><td>HW2b</td><td>Midterm</td><td>HW3</td><td>FExam</td></tr>\n";
        if ($result = mysqli_store_result($db))
        {
          while ($row = mysqli_fetch_array($result))
          {
            if($row["Error Message"]){
              echo "Invalid Input. Query failed!\n";
            }
            else{



                  printf("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>\n", $row["SSN"], $row["LName"], $row["FName"], $row["Section"], $row["HW1"], $row["HW2a"], $row["HW2b"], $row["Midterm"], $row["HW3"], $row["FExam"]);




                }
          }
        } echo "</table>\n";echo PHP_EOL;
      } while(mysqli_next_result($db)&&mysqli_more_results($db));
    }


}

// PHP code about to end

 ?>



 <body>