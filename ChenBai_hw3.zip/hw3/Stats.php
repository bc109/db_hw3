 <head>
  <title>Stats</title>
</head>
<body>
 <?php
// PHP code just started

//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', true);

ini_set("display_errors", 0);

//error_reporting(E_ALL ^ E_NOTICE);

//error_reporting(E_ALL ^ E_WARNING);
// display errors

$db = mysqli_connect("dbase.cs.jhu.edu", "20fa_cbai6", "lCkL3uhlXF");
// ********* Remember to use your MySQL username and password here ********* //

if (!$db) {

  echo "Connection failed!";

} else {
  $password = $_POST['password'];
  // This says that the $cr_cnt variable should be assigned a value obtained as an
  // input to the PHP code. In this case, the input is called 'cr_cnt'.


  mysqli_select_db($db,"20fa_cbai6_db");
  // ********* Remember to use the name of your database here ********* //

$x=1;
  if(mysqli_multi_query($db, "CALL Stats('$password')")){
      do
      { if($x%4 == 1){echo "Mean";}
        if($x%4 == 2){echo "Minimum";}
        if($x%4 == 3){echo "Maximum";}
        if($x%4 == 0){echo "Std. Dev";}
        $x++;
        echo "<table border=1>\n";
        echo "<tr><td>Statistic</td><td>Section</td><td>HW1</td><td>HW2a</td><td>HW2b</td><td>Midterm</td><td>HW3</td><td>FExam</td><td>CumAvg</td></tr>\n";
        if ($result = mysqli_store_result($db))
        {
          while ($row = mysqli_fetch_array($result))
          {
            if($row["Error Message"]){
              echo "Invalid Input. Query failed!\n";
            }
            else{



                  printf("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>\n", $row["Statistic"], $row["Section"], $row["HW1"], $row["HW2a"], $row["HW2b"], $row["Midterm"], $row["HW3"], $row["FExam"], $row["CumAvg"]);




                }
          }
        } echo "</table>\n";echo PHP_EOL;
      } while(mysqli_next_result($db)&&mysqli_more_results($db));
    }


}

// PHP code about to end

 ?>



 <body>